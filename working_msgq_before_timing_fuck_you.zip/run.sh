#!/bin/bash
gcc random.c stopwatch.c new.c -lm -o cnew
gcc random.c stopwatch.c upgrade.c -lm -o cupgrade
gcc random.c stopwatch.c repair.c -lm -o crepair
gcc random.c sorter.c -lm -o sorter
gcc stopwatch.c random.c main.c  -lm -o main
./main
